# FocusTrack

Ferramenta minimalista open-source para produtividade usando a técnica Pomodoro, com integração ao Telegram.
